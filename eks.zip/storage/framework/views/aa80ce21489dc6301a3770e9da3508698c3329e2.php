<?php $__env->startSection('content'); ?>
<div class="page-title">
    <div class="row">
        <div class="col-12 col-md-6 order-md-1 order-last">
            <h3>Prestasi</h3>
        </div>
        <div class="col-12 col-md-6 order-md-2 order-first">
            <nav aria-label="breadcrumb" class="breadcrumb-header">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('userIndex')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Prestasi</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<section class="section">
    <div class="card">
        <div class="card-body">
            <table class='table table-hover' id="table1">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Gambar</th>
                        <th>Prestasi</th>
                        <th>Ekstrakurikuler</th>
                        <th>Tahun</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $daftarPrestasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td>
                            <img src="<?php echo e(asset('img/'.strtolower(str_replace(' ', '-', $data->ekstrakurikuler->ekstrakurikuler))).'/'.$data->gambar); ?>" alt="" width="100">
                        </td>
                        <td><?php echo e($data->prestasi); ?></td>
                        <td><?php echo e($data->ekstrakurikuler->ekstrakurikuler); ?></td>
                        <td><?php echo e($data->tahun); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eks\resources\views/user/prestasi.blade.php ENDPATH**/ ?>