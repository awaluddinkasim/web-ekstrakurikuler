<?php $__env->startSection('content'); ?>
<div class="page-title">
    <div class="row">
        <div class="col-12 col-md-6 order-md-1 order-last">
            <h3>Edit Sejarah</h3>
        </div>
        <div class="col-12 col-md-6 order-md-2 order-first">
            <nav aria-label="breadcrumb" class="breadcrumb-header">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('adminIndex')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="#">Profil</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('adminIndex').'/profil/sejarah'); ?>">Sejarah</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Edit</li>
                </ol>
            </nav>
        </div>
    </div>
</div>


<section class="section">
    <div class="card">
        <div class="card-body">
            <form action="" method="post" id="formSejarah">
                <?php echo csrf_field(); ?>
                <div data-tiny-editor id="editorSejarah">
                    <?php echo isset($data->value) ? $data->value : ''; ?>

                </div>
                <input type="hidden" name="sejarah" id="sejarah" value="">
                <div class="clearfix mt-2">
                    <button class="btn btn-primary float-end" type="button" id="btnSimpan">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $('#btnSimpan').click(function() {
            var editor_content = $('#editorSejarah').html();
            $('#sejarah').val(editor_content);
            $('#formSejarah').submit();
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eks\resources\views/admin/sejarah-edit.blade.php ENDPATH**/ ?>