<?php $__env->startSection('content'); ?>
<div class="page-title">
    <div class="row">
        <div class="col-12 col-md-6 order-md-1 order-last">
            <h3><?php echo e(ucfirst($jenis)); ?> Kegiatan</h3>
        </div>
        <div class="col-12 col-md-6 order-md-2 order-first">
            <nav aria-label="breadcrumb" class="breadcrumb-header">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('adminIndex')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="#">Kegiatan</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e('/'.md5('admin').'/kegiatan/'.$jenis); ?>"><?php echo e(ucfirst($jenis)); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Edit</li>
                </ol>
            </nav>
        </div>
    </div>
</div>

<form action="" method="POST"></form>
<div class="col-md-12">
    <div class="card">
        <div class="card-body">
            <form action="" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="nama">Nama Kegiatan</label>
                    <input type="text" class="form-control" id="nama" name="nama" autocomplete="off" value="<?php echo e($data->nama); ?>" required>
                </div>
                <div class="row">
                    <div class="form-group col-md-6">
                        <label for="mulai">Tanggal Mulai</label>
                        <input type="date" class="form-control" id="mulai" name="mulai" value="<?php echo e($data->tgl_mulai); ?>" required>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="jam_mulai">Pukul</label>
                        <input type="time" class="form-control" id="jam_mulai" name="jam_mulai" value="<?php echo e(Carbon\Carbon::parse($data->jam_mulai)->format('H:i')); ?>" required>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-6">
                        <label for="selesai">Tanggal Selesai</label>
                        <input type="date" class="form-control" id="selesai" name="selesai" value="<?php echo e($data->tgl_selesai); ?>" required>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="jam_selesai">Pukul</label>
                        <input type="time" class="form-control" id="jam_selesai" name="jam_selesai" value="<?php echo e(Carbon\Carbon::parse($data->jam_selesai)->format('H:i')); ?>" required>
                    </div>
                </div>
                <div class="clearfix">
                    <button type="submit" class="btn btn-primary float-end">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eks\resources\views/admin/kegiatan-edit.blade.php ENDPATH**/ ?>