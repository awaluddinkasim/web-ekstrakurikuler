<?php $__env->startSection('content'); ?>
<div class="page-title">
    <div class="row">
        <div class="col-12 col-md-6 order-md-1 order-last">
            <h3>Ekstrakurikuler</h3>
        </div>
        <div class="col-12 col-md-6 order-md-2 order-first">
            <nav aria-label="breadcrumb" class="breadcrumb-header">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('adminIndex')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Ekstrakurikuler</li>
                </ol>
            </nav>
        </div>
    </div>
</div>

<form action="" method="POST"></form>
<div class="col-md-12">
    <div class="card">
        <div class="card-body">
            <form action="" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="nama">Nama Ekstrakurikuler</label>
                    <input type="text" class="form-control" id="nama" name="nama" autocomplete="off" value="<?php echo e($data->ekstrakurikuler); ?>" required>
                </div>
                <div class="form-group">
                    <label for="ketua">Ketua</label>
                    <select class="choices form-select" id="ketua" name="ketua" required>
                        <option value="">Pilih</option>
                        <?php $__currentLoopData = $daftarSiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($siswa->username); ?>" <?php echo e($data->ketua->username == $siswa->username ? 'selected' : ''); ?>><?php echo e($siswa->username); ?> - <?php echo e($siswa->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pembina">Nama Pembina</label>
                    <input type="text" class="form-control" id="pembina" name="pembina" autocomplete="off" value="<?php echo e($data->pembina); ?>" required>
                </div>

                <div class="clearfix">
                    <button type="submit" class="btn btn-primary float-end">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eks\resources\views/admin/ekstrakurikuler-edit.blade.php ENDPATH**/ ?>