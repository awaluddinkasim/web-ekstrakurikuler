<?php $__env->startSection('content'); ?>
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3>Ekstrakurikuler</h3>
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('userIndex')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Ekstrakurikuler</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <section class="section">
        <div class="card">
            <div class="card-body">

                <table class='table table-hover' id="table1">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama</th>
                            <th>Ketua</th>
                            <th>Pembina</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $daftarData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($data->ekstrakurikuler); ?></td>
                            <td><?php echo e($data->ketua->nama); ?></td>
                            <td><?php echo e($data->pembina); ?></td>
                            <td class="text-center">
                                <?php if(auth()->user()->formulir->count() > 0): ?>
                                    <?php
                                        $formulir = auth()->user()->formulir->where('id_ekstrakurikuler', $data->id)->first();
                                    ?>
                                    <?php if($formulir): ?>
                                        <?php if($formulir->status == 'pending'): ?>
                                        <form action="<?php echo e(Request::url().'/'.md5('batal')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <input type="hidden" name="id" value="<?php echo e($formulir->id); ?>">
                                            <button class="btn btn-danger btn-sm" type="submit">Batal</button>
                                        </form>
                                        <?php else: ?>
                                        <span class="<?php echo e($formulir->status == 'diterima' ? 'text-success' : 'text-danger'); ?>"><?php echo e(ucfirst($formulir->status)); ?></span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <button class="btn btn-success btn-sm" onclick="document.location.href = '<?php echo e(Request::url().'/'.$data->id); ?>'">Daftar</button>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <button class="btn btn-success btn-sm" onclick="document.location.href = '<?php echo e(Request::url().'/'.$data->id); ?>'">Daftar</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eks\resources\views/user/ekstrakurikuler.blade.php ENDPATH**/ ?>