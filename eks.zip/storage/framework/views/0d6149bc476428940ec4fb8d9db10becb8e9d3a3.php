<?php $__env->startSection('content'); ?>
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3>Data <?php echo e(auth()->user()->ekstrakurikuler->ekstrakurikuler); ?></h3>
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('userIndex')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Pendaftar</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <section class="section">
        <div class="card">
            <div class="card-body">
                <div class="card-title">Pendaftar Ekstrakurikuler <?php echo e(auth()->user()->ekstrakurikuler->ekstrakurikuler); ?></div>
                <table class='table table-hover' id="table1">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama</th>
                            <th>Usia</th>
                            <th>Jenis Kelamin</th>
                            <th>No. HP</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendaftar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($pendaftar->pendaftar->nama); ?></td>
                            <td><?php echo e($pendaftar->usia); ?></td>
                            <td><?php echo e($pendaftar->pendaftar->jk == 'L' ? 'Laki-laki' : 'Perempuan'); ?></td>
                            <td>0<?php echo e($pendaftar->hp); ?></td>
                            <td class="<?php echo e($pendaftar->status == 'diterima' ? 'text-success' : 'text-danger'); ?>"><?php echo e(ucfirst($pendaftar->status)); ?></td>
                            <td class="text-center">
                                <button class="btn btn-outline-success btn-sm" onclick="document.location.href = '<?php echo e(Request::url().'/'.$pendaftar->id); ?>'">Periksa</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eks\resources\views/user/ekstrakurikuler-pendaftar.blade.php ENDPATH**/ ?>